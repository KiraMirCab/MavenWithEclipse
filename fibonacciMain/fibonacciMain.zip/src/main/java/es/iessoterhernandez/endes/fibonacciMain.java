package es.iessoterhernandez.endes;

public class fibonacciMain {

	public static void main(String[] args) {
		fibonacci f = new fibonacci();
		 
		        // Given Number N 
		        int N = 10; 
		  
		        // Function Call 
		        f.Fibonacci(N); 
		    } 
	

}
